package io.study.bootdocker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootdockerApplicationTests {

	@Test
	void contextLoads() {
	}

}
